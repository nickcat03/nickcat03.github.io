This is GoldenEpsilon's practice hack for KSS speedrunning, v5.2
Please note that it isn't perfect and that there are a few bugs, read below:

Features: 
Frame Counter (your score ticks up by 10 per rendered frame)
Ability swapper (press L+A to change your ability)
Level skip (press R+A to finish the level instantly)
Save/Load states (L+Select to save a state, R+Select to load)

Issues:
-The frame counter does not appear everywhere, and only ticks up on frames that something is rendered.
-Ability swapping rarely doesn't work correctly and resets to cutter when it should give a different ability.
-Ability swapping multiple times in a row leaves the background darkened until a room load occurs (or another
 effect that changes the background shade)
-Level skip is consistently inconsistent, giving a death on the fourth level of Dynablade, and skipping two levels
 at a time in RoMK. Also, don't use on boss levels or levels of RoMK that are even-numbered. (so basically you
 can level skip to the set of two levels you want, but you can't do skip -> beat a level -> skip, you have to do
 skip -> beat -> beat -> skip)
-Save states are very limited right now. They save position of Kirby and enemies, and all the physics are the
 same, but:
  -- Room layouts are not changed to match
  -- Visuals are buggy if there is something like a different ability when you load
  -- The camera has to move to Kirby after loading a state in certain situations
  -- Game can crash when saving / loading a state in certain situations (mostly boss fights)
